#!/bin/sh

# resolve urls from package list
ruby extract_urls.rb pkg_list.txt > urls.txt

# fetch deb files
ruby fetch_debs.rb urls.txt

