#!/usr/bin/ruby2.1 -Ku
# -*- mode: ruby; coding: utf-8-unix -*-

def check_internal(dg, pkgs)
   last = nil
   found = dg.any? do |name,ver|
      last = name
      pkgs.has_key?(name) && ver =~ /= (.*)$/ && $1 == pkgs[name][0]
   end

   if found then
      last
   else
      nil
   end
end

def check_external(dg)
   dg.any? do |name,ver|
      satisfy = false
      iver = `dpkg-query -W -f '${Version}' #{name}`
      if $?.success? then
         if ver.nil? then
            satisfy = true
         else
            system "dpkg", "--compare-versions", iver, *(ver.split(/\s+/))
            if $?.success? then
               satisfy = true
            end
         end
      end
      satisfy
   end
end

def need_external(name, depends)
   dlist = depends[name]

   exts = []
   dlist.each do |dg|
      unless check_external(dg) then
         exts.push dg
      end
   end

   return exts
end

def parse_depend(str)
   deps = str.split(/\s*,\s*/).collect do |dg|
      dg.split(/\s*\|\s*/).collect do |de|
         if de =~ /^(\S+)(?:\s+\((.*)\))?/ then
            name = $1
            ver = $2
            [name,ver]
         else
            raise "Couldn't parse dependency entry: #{de}"
         end
      end
   end
   return deps
end

def get_pkg_info(filename)
   info = nil
   IO.popen(["dpkg-deb", "-I", filename], "r") do |fd|
      unless block_given? then
         info = fd.read
      else
         fd.each do |line|
            yield line
         end
      end
   end
   info
end

d = Dir.glob("archive/*.deb")

pkgs = {}

d.each do |deb|
   pkginfo = `dpkg-deb -W #{deb}`
   name, ver = pkginfo.split(/\s+/)
   pkgs[name] = [ver, deb]
end

pnames = pkgs.keys.sort

depends = {}

pnames.each do |n|
   ver, filename = pkgs[n]
   depstr = `dpkg-deb -W --showformat='${Depends}' #{filename}`
   dlst = parse_depend(depstr)
   depends[n] = dlst
end

int_depends = {}

pnames.each do |n|
   ints = []
   dlst = depends[n]
   new_dlst = dlst.reject do |dg|
      m = check_internal(dg, pkgs)
      unless m.nil? then
         ints.push m
         true
      else
         false
      end
   end

   depends[n] = new_dlst
   int_depends[n] = ints
end

ext_depends = {}

pnames.each do |n|
   exts = need_external(n, depends)
   ext_depends[n] = exts
end

while true
   updated = false

   pnames.each do |n|
      ilst = int_depends[n]
      new_elst = ext_depends[n].dup
      new_ilst = ilst.reject do |di|
         if ext_depends[di].size > 0 then
            ver, = pkgs[di]
            new_elst.push [[di,ver]]
            updated = true
         end
      end
      ext_depends[n] = new_elst
      int_depends[n] = new_ilst
   end

   break  unless updated
end

flst_avail = []
printf "Unmet dependency:\n"
pnames.each do |n|
   elst = ext_depends[n]
   if elst.size > 0 then
      printf "  %s: %s\n", n, elst.collect{|dg| dg.collect{|name,ver| name}.join(" | ")}.join(", ")
   else
      ver, filename = pkgs[n]
      flst_avail.push filename
   end
end

printf "\n"
if ARGV[0] == "--gogogo" then
   printf "Install available files...\n"
   cmd = ["sudo", "dpkg", "-i", "-E"] + flst_avail
   printf "%s\n", cmd.join(" ")
   system *cmd
end

# Local Variables:
# ruby-indent-level: 3
# indent-tabs-mode: nil
# End:
