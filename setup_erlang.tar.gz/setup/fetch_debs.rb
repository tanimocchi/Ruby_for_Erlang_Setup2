#!/usr/bin/ruby2.1 -Ku
# -*- mode: ruby; coding: utf-8-unix -*-

require 'fileutils'

dst_dir = "./archive"
FileUtils.mkdir_p dst_dir

fail_list = []

ARGF.each do |line|
   next  if line =~ /^#/

   line.chomp!
   url = line.split(/\s+/)[-1]
   fname = url[url.rindex("/"), url.length]
   out_path = dst_dir + fname
   cmd = ["wget", "-O", out_path, url]
   printf "%s\n", cmd.join(" ")
   system *cmd
   unless $?.success? then
      fail_list.push url
      system "rm", "-f", out_path
   end
end

if fail_list.size > 0 then
   printf "Failed to fetch following files:\n"
   fail_list.each do |url|
      printf "  %s\n", url
   end
   printf "\n"
   exit 1
end

# Local Variables:
# ruby-indent-level: 3
# indent-tabs-mode: nil
# End:
