#!/usr/bin/ruby2.1 -Ku
# -*- mode: ruby; coding: utf-8-unix -*-

def get_pkg_info(name, fp)
   pkg_info = {"Package" => name}
   while true
      line = fp.gets
      raise "Unexpected EOF."  if line.nil?

      line.chomp!
      break  unless line =~ /\S/

      if line =~ /^([^:]+): (.*)$/ then
         field = $1
         value = $2
         pkg_info[field] = value
      end
   end

   pkg_info
end

Server_Path = "http://ring.shibaura-it.ac.jp/archives/linux/debian/debian/"
#Server_Path = "http://ftp.jp.debian.org/debian/"
Dist_Name = "stretch"
Arch_Name = "amd64"
Dist_Path = Server_Path + "dists/" +  Dist_Name + "/main/binary-" + Arch_Name + "/"

Packages_File = "Packages.xz"
Packages_URL = Dist_Path + Packages_File

pkgs = {}
# Read package names from stdin
ARGF.each do |line|
   next  if line =~ /^#/
   next  unless line =~ /\S/

   name = line.chomp
   pkgs[name] = true
end

cmd = ["wget", "-O", "./#{Packages_File}", Packages_URL]
STDERR.printf "%s\n", cmd.join(" ")
system *cmd

unless $?.success? then
   STDERR.printf "Failed to get package list: %s\n", Packages_URL
   exit 1
end

pkg_info = {}
begin
   f = IO.popen(["xzcat", Packages_File], "r", :external_encoding => "UTF-8")

   while true
      line = f.gets
      break  if line.nil?

      line.chomp!
      if line =~ /^Package:\s+(.*)$/ then
         pkg_name = $1
         if pkgs.has_key?(pkg_name) then
            entry = get_pkg_info(pkg_name, f)
            pkg_info[pkg_name] = entry
         end
      end
   end
ensure
   f.close
end

pkgs.keys.sort.each do |name|
   if pkg_info.has_key?(name) then
      entry = pkg_info[name]
      version  = entry["Version"]
      filename = entry["Filename"]
      url = Server_Path + filename
      printf "%s(%s): %s\n", name, version, url
   else
      printf "# Not Found: %s\n", name
   end
end


# Local Variables:
# ruby-indent-level: 3
# indent-tabs-mode: nil
# End:
